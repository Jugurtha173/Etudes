#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define max 20
#define min 0

#define Taille 50
#define SIZE_MAX 50



// fonction affichage tableau
void afficheTab(int tab[Taille]){
for(int i = 1 ; i <= Taille ; i++){
    printf(" %3d |",tab[i-1]);
    if(i % 10 == 0)
        printf("\n");
}
}

void afficheMat(int n, int m, int** tabNotes){
for(int i = 0; i < n; i++){
    for(int j = 0; j < m;j++){
        printf(" %3d |",tabNotes[i][j]);

    }
    printf("\n");
}
printf("______________________________________________________________________________________________\n\n");
}

void ligne(int n){
    for(int i = 0; i < n; i++){
        printf("**********\n");
    }
}

float moyenne(int a, int b,int c){
return (a+b+c)/3.0;
}

float delta(float a, float b, float c){
return (b*b -4*a*c);
}

void triBulles(int tab[], int taille){
    int temp;
    for(int j = 0; j < taille ; j++){
        for(int i = 0; i < taille-j ; i++){
            if(tab[i] > tab[i+1]){
                temp = tab[i];
                tab[i] = tab[i+1];
                tab[i+1] = temp;
            }
        }
    }
}

void moyenneEtu(int lignes, int colones, int** tabNotes){

    for(int i = 0; i  < lignes; i++){
        int somme = 0;
        for(int j = 0; j < colones; j++){
                //printf(" %3d |",tabNotes[i][j]);
          somme += tabNotes[i][j];
        }
        printf("la moyenne de l'etudiant numero %d = %.2f\n", i , ((float)somme / colones));
    }
printf("______________________________________________________________________________________________\n\n");

//trois cents millions quatre cents mille

}

void moyenneMat(int lignes, int colones, int** tabNotes){

for(int j = 0; j  < colones; j++){
        int somme = 0;
        for(int i = 0; i < lignes; i++){
          somme += tabNotes[i][j];
        }
        printf("la moyenne de la matiere numero %d = %.2f\n", j , ((float)somme / lignes));
    }
printf("______________________________________________________________________________________________\n\n");

}

void bestNoteMat(int n, int m, int** tabNotes, int mat){
int note = 0;
for(int j = 0; j < n; j++){
    if(tabNotes[j][mat] > note)
        note = tabNotes[j][mat];
}
printf("la best note dans la matiere numero %d = %d\n", mat , note);
printf("______________________________________________________________________________________________\n\n");

}

void bestNoteChaqueMat(int lignes, int colones, int** tabNotes){

for(int j = 0; j  < colones; j++){
        int note = 0;
        for(int i = 0; i < lignes; i++){
          if(note < tabNotes[i][j])
             note = tabNotes[i][j];
        }
        printf("la best note de la matiere %d est %3d\n",j, note);
    }
printf("______________________________________________________________________________________________\n\n");
}

void bestNoteSemstre(int lignes, int colones, int** tabNotes){
    int note = 0;
    int posi = 0;
    int posj = 0;

for(int i = 0; i  < lignes; i++){
    for(int j = 0; j < colones; j++){
      if(note < tabNotes[i][j])
         note = tabNotes[i][j];
         posi = i;
         posj = j;
    }
    }
printf("la best note du semstre est de %d/20 detenue par l'etudiant numero %d dans la matiere numero %d\n", note, posi,posj);

printf("______________________________________________________________________________________________\n\n");
}


int fact(int n){
if(n<0) fprintf( stderr, "erreur nbr neg");
else
if(n == 0) return 1;
else return n * fact(n-1);
}

int fibo(int U0, int U1, int n){
    if( n==U0 ) return n;
    else if (n == U1) return n;
    else
        return fibo(U0,U1, n-1) + fibo(U0,U1, n-2);
}

int valMin(int tab[],int mini, int i){
    if (i >= SIZE_MAX) return mini;
        else
            if(tab[i] < mini)
            return valMin(tab, tab[i],i+1);
        else return valMin(tab, mini, i+1);

};


void insert(int tab[], int i, int j){
    int temp = tab[i];
    for(int k = i; k > j; k--)
        tab[k] = tab[k-1];
    tab[j] = temp;
}

void triSel(int tab[], int ind){
    for(int i = ind; i<SIZE_MAX; i++){
        for(int j = 0; j < i; j++){
            if( ((tab[i] < tab[j]) && (tab[i] >= tab[j-1])) || ( (j==0) && (tab[i] < tab[j]) ) ){
                insert(tab ,i, j);
            }
        }
    }
}


int cmp=0;
int pivot(int tab[], int t1, int t2){
    int piv = t1;
if(t1 < t2){
    for(int i = piv+1 ; i <= t2 ; i++){
        if(tab[piv] > tab[i]){
            printf("_________________________________appel numero : %d_________________________________\n\n",cmp++);
            insert(tab , i , piv);
            piv++;
        }
    }
       pivot(tab , t1 , piv);
       pivot(tab , piv+1 , t2) ;
}
return piv;
}


int main()
{

/* Q1 et Q2

int tab[Taille];
// int temp;

srand(time(NULL));

for(int i = 0; i < Taille; i++){
    tab[i] = (rand() % (max - min +1) + min);
}

affiche(tab);

triBulles(tab , Taille);
/*
for(int j = 0; j < Taille ; j++){
    for(int i = 0; i < Taille-j ; i++){
        if(tab[i] > tab[i+1]){
            temp = tab[i];
            tab[i] = tab[i+1];
            tab[i+1] = temp;
        }
    }
}

printf("\n\n\n");
affiche(tab);


/*____________________________________________________________*/

/* Q1 et Q2

ligne(50);
/*____________________________________________________________*/

/* Q3
printf("%.2f", moyenne(1 , 7 , 3));
/*____________________________________________________________*/

/* Q5
printf("le delta = %.2f", delta(2.0 , 3.0 , 4.0));
/*____________________________________________________________*/

// Q6

int n,m;

printf("saisir le nombre d'etudiants \n");
scanf("%d",&n);

printf("saisir le nombre de matieres \n");
scanf("%d",&m);


int **tableau ;
tableau = (int **)malloc(sizeof(int *) * n);

for(int i = 0 ; i < n; i++)
    tableau[i] = (int *)malloc(sizeof(int) * m);


for(int i = 0 ; i < n ; i++){
    for(int j= 0 ; j < m ; j++){
        tableau[i][j] = (rand() % (max - min +1) + min);
        //printf(" %3d |",tableau[i][j]);
    }
    //printf("\n" );
}
//printf("\n\n\n\n" );


afficheMat(n, m, tableau);

moyenneEtu(n, m, tableau);

moyenneMat(n, m, tableau);

bestNoteMat(n, m, tableau, 2);

bestNoteChaqueMat(n, m, tableau);

bestNoteSemstre(n , m ,tableau);


/*____________________________________________________________*/


/* recursivit� Q1
int n;
printf("saisir un nombre\n");
scanf("%d",&n);

printf("%d! = %d\n", n , fact(n));
/*____________________________________________________________*/

/* Q2

printf("%d", fibo(0,1,29));

/*____________________________________________________________*/

/* Q3

int tab[SIZE_MAX];

srand(time(NULL));

for(int i = 0; i < SIZE_MAX; i++){
    tab[i] = (rand() % (max - min +1) + min);
}


afficheTab(tab);

printf("\n%d",valMin(tab, tab[0], 0));

/*____________________________________________________________*/


// Tri par insertion

int tab[SIZE_MAX];

srand(time(NULL));

for(int i = 0; i < SIZE_MAX; i++){
    tab[i] = (rand() % (max - min +1) + min);
}

afficheTab(tab);

printf("\n \n \n");

triSel(tab,1);

afficheTab(tab);

/*____________________________________________________________*/

/* Tri rapide

int tab[SIZE_MAX];

srand(time(NULL));

for(int i = 0; i < SIZE_MAX; i++){
    tab[i] = (rand() % (max - min +1) + min);
}

afficheTab(tab);

printf("\n \n \n");

pivot(tab , 0 ,SIZE_MAX-1);

printf("\n \n \n");

afficheTab(tab);

/*____________________________________________________________*/


return 0;
}
