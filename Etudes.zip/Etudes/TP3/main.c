#include <stdio.h>
#include <stdlib.h>

const arrJour[8][10] = {" ","lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"};

const arrMois[13][10] = {" ","janvier","fevrier","mars","avril","mai","juin","juillet","aout","septembre","novembre","decembre"};

typedef enum {
lundi=1, mardi=2, mercredi=3, jeudi=4, vendredi=5, samedi=6, dimanche=7
}T_jour;

typedef enum{
janvier=1,fevrier=2,mars=3,avril=4,mai=5,juin=6,juillet=7,aout=8,septembre=9,octobre=10,novembre=11,decembre=12
}T_mois;

/*typedef struct{
    T_jour jour;
    int numJour;
    T_mois mois;
    int annee;
}T_date;


void afficheDate(T_date D){
printf("la date est : %s %d %s %d\n ",arrJour[D.jour], D.numJour, arrMois[D.mois], D.annee);
}

T_date saisieDate(){
    T_date date;

    printf("saisir le jour\n");
    scanf("%d",&date.jour);

    printf("saisir le jour du mois\n");
    scanf("%d",&date.numJour);

    printf("saisir le mois\n");
    scanf("%d",&date.mois);

    printf("saisir l'annee\n");
    scanf("%d",&date.annee);

return date;
}

T_date saisie(){
    T_date date;

    printf("saisir le jour\n1:lundi\n2: mardi\n3: mercredi\n4: jeudi\n5: vendredi\n6: samedi\n7: dimanche\n");
    scanf("%d",&date.jour);

    printf("saisir le jour du mois\n");
    scanf("%d",&date.numJour);

    printf("saisir le mois\n1:janvier\n2: fevrier\n3: mars\n4: avril\n5: mai\n6: juin\n7: juillet\n8: aout\n9: septembre\n10: octobre\n11: novembre\n12: decembre\n");
    scanf("%d",&date.mois);

    printf("saisir l'annee\n");
    scanf("%d",&date.annee);

    return date;
}

void modifDate(T_date *D, int an){
    D->annee = an;
}


void affichePtr(int *p){
    printf("le contenu du pointeur = %x\nl'adresse du pointeur = %x\nla valeur pointee = %d\nl'adresse de la valeur = %x\n", p , &p , *p , p);
}

*/

int main()
{
/* exo 1

    date.jour = 3;
    date.numJour = 17;
    date.mois = 3;
    date.annee = 2020;


   // T_date date = saisie();
   // afficheDate(date);

   // modifDate(&date , 2019);

    //afficheDate(date);


/*________________________________________________*/

/* Q1


int a = 5;
int *p = &a;
int *q = NULL;

int b = *p;

int *ptr = &p;


affichePtr(ptr);

scanf("%d",(*ptr));

affichePtr(p);


printf("%d",a);




/*________________________________________________*/

/* Q2
int tab[7];
int *ptr = &tab[0];

for(int i = 0; i < 7;i++)



/*________________________________________________*/


    return 0;
}
