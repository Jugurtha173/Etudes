#include <stdio.h>
#include <stdlib.h>
#include "image.h"



int main(){

FILE* file = NULL;
file = fopen("IMG.ppm" , "r+");

if(file == NULL) printf("no");
else printf("oui");


return 0;
}
