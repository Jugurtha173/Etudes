#include <stdio.h>
#include <stdlib.h>

typedef struct{
unsigned char r;
unsigned char g;
unsigned char b;
}pixel;


typedef struct{
    int sizeX;
    int sizeY;
    pixel **pix;
}image;
