#include <stdio.h>
#include <stdlib.h>
#include <windows.h>


typedef struct {
    int jour;
    int mois;
    int annee;
}T_date;

typedef struct {
    char nom[50];
    char prenom[50];
    T_date DDN;
}T_personne;

void saisiePersonne(T_personne *p){
    printf("saisir le nom\n");
    scanf("%s",p->nom);

    printf("saisir le prenom\n");
    scanf("%s",p->prenom);

/*    printf("saisir le jour\n");
    scanf("%d",&p->DDN.jour);

    printf("saisir le mois\n");
    scanf("%d",&p->DDN.mois);

    printf("saisir l'annee\n");
    scanf("%d",&p->DDN.annee);
*/
}

void permute(T_personne *p1 , T_personne *p2){
T_personne temp;

temp = *p1;
*p1 = *p2;
*p2 = temp;
}

void rempTab(T_personne *tab, int taille){

for(int i = 0 ; i < taille ; i++)
        saisiePersonne(&tab[i]);
}

void affichage(int *T , int n){
    int *p = &T[0];

    for(int i = 0; i < n; i++){
        printf(" % x  %d\n", &T[i] , T[i]);
        printf(" % x  %d\n", p+i , *(p+i));
    }
}

// Les Piles
struct cellule{
    int val;
    struct cellule *suiv;
};

typedef struct cellule *T_pile;

T_pile createPile(){
    T_pile p = NULL;
    return p;
}

T_pile empiler(T_pile p , int donnee){
    T_pile element = (struct cellule *)malloc(sizeof(struct cellule));
    element->val = donnee;
    element->suiv = p;

    return element;
}

int depiler(T_pile *p){
    int v = -1;
    if(*p != NULL){
        T_pile tmp = *p;
        *p = tmp -> suiv;
        free(tmp);
    }
    return v;
}

void affichePile(T_pile p){ // recursive

if(p != NULL){
        printf(" %3d |",p->val);
        affichePile(p->suiv);
    }
}

void affichePileInv(T_pile p){ // recursive inverse
if(p != NULL){
        affichePile(p->suiv);
        printf(" %3d |",p->val);
    }
}

//Les files

typedef struct T_cellule{
    T_personne val;
    struct T_cellule* suiv;
}T_cellule;

typedef struct{
    T_cellule *deb;
    T_cellule *fin;
}T_file;

T_file cerateFile(){
    T_file f;
    f.deb = NULL;
    f.fin = NULL;
return f;
}

void enfiler(T_file *f , T_personne p){ // on met un pointeur sur une file pour sauvgarder les modification (car c'est un void)
    T_cellule *nouveau = (T_cellule *)malloc(sizeof(T_cellule));
    nouveau->val = p;
    nouveau->suiv = NULL;

    if(f->deb == NULL){
        f->deb = f->fin = nouveau;
    }
    else{
        f->fin->suiv = nouveau;
        f->fin = nouveau;
    }
}

void defiler(T_file *f){
T_cellule *tmp = f->deb;
if(f->deb != NULL){
    f->deb = f->deb->suiv;
    free(tmp);
    if(f->deb == NULL)
        f->fin = NULL;
}

}

void afficheP(T_file f){

SYSTEMTIME Time;
GetLocalTime(&Time);
printf ("Aujourd\�hui, nous sommes le : %02d/%02d/%04d et il est %02dh %02dmn %02ds %03dms.\n", Time.wDay, Time.wMonth, Time.wYear, Time.wHour, Time.wMinute, Time.wSecond
, Time.wMilliseconds);

while( f.deb != NULL){
    printf("le nom est : %s\n",f.deb->val.nom);
    printf("le prenom est : %s\n",f.deb->val.prenom);
    printf("l'age est : %d\n",Time.wYear - f.deb->val.DDN.annee);
}


}
/*
T_personne p1 , p2;
T_personne *T;
int n;
*/
int main()
{
/*
    int T[10] = {7,12,21,33,49,57,62,77,80,99}; // creer tab remplie

    int *p = T;

    printf("%d\n", *p+3);
    printf("%d\n", *(p+3));
    printf("%d\n", &p+3);
    printf("%d\n", &T[5]-3);
    printf("%d\n", T+2);
    printf("%d\n", &T[7]-p);
    printf("%d\n", p+(*p-5));
    printf("%d\n", *(p+*(p+8)-T[7]));

*/

/*
    printf("saisir la taille du tableau\n");
    scanf("%d",&n);

    T = (T_personne *)malloc(sizeof(T_personne)*n);

    rempTab(T , n);

for(int i =0; i<n;i++){
    printf("% s |",T[i].prenom);
}

permute(&T[0], &T[1]);

for(int i =0; i<n;i++){
    printf("% s |",T[i].prenom);
}

/*_____________________________________________________________*/

/*
    saisiePersonne(&p1);
    saisiePersonne(&p2);

    printf("le nom de p1 est : %s\n",p1.nom);
    printf("le nom de p2 est : %s\n",p2.nom);

    permute(&p1 , &p2);

    printf("le nom de p1 est : %s\n",p1.nom);
    printf("le nom de p2 est : %s\n",p2.nom);
*/




    return 0;
}
