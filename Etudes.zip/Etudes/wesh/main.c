#include <windows.h>
#include <conio.h>
#include <stdio.h>
#define MAX 10

char laby[MAX][MAX] = {
"**********",
"* *  *****",
"* *  *** *",
"*    *****",
"* ** *  **",
"*   *** **",
"* *   ****",
"* ***   **",
"****     0",
"**********"
};

void Color(int couleurDuTexte,int couleurDeFond) // fonction d'affichage de couleurs
{
  HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(H,couleurDeFond*16+couleurDuTexte);
}

void Locate(int x,int y)
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD C;
    C.X=(SHORT)x;
    C.Y=(SHORT)y;
    SetConsoleCursorPosition(H,C);
}

void Afficher(int x,int y)
{
    int i,j;
    Locate(0,0);
    for(i=0;i<MAX;i++)
    {
        for(j=0;j<MAX;j++)
        {
            if (i==x && j==y){
                Color(0,5);
                printf(" ");
                Color(15,0);
            }
            else
                printf("%c",laby[i][j]);
        }
        printf("\n");
    }
}

void TryMove(int* x,int* y,int vx,int vy)
{
    if(laby[*x+vx][*y+vy]=='*'){
        printf("\a");
        return;
       }
    if (laby[*x+vx][*y+vy]=='0'){
        printf("Vous avez gagne!!!! \a\a\a\a");

    }
    (*x)+=vx;
    (*y)+=vy;
}

int main()
{
    int x,y;  // position joueur
    int touche = 0;
    x = y = 1;
    while(touche!=27) // 27 = ECHAP
    {
        Afficher(x,y);
        touche = getch();
        switch(touche)
        {
        case 'q':
            TryMove(&x,&y,0,-1);
            break;
        case 'd':
            TryMove(&x,&y,0,1);
            break;
        case 'z':
            TryMove(&x,&y,-1,0);
            break;
        case 's':
            TryMove(&x,&y,1,0);
        default:
            break;
        }
    }
    return 0;
}
