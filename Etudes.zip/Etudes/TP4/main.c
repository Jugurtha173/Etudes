#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../TP3biblio/alloc.h"
#include "../TP3biblio/tri.h"
#include <unistd.h>
#include <Windows.h>


int main(int argc , char* argv[])
{

 /* exo 1
    printf("le nombre d'argument (nom du programme inclu) est de : %d\n",argc);

    for(int i = 0 ; i < argc ; i++)
        printf("argument numero %d est : %s\n",i,argv[i]);

/*_________________________________________________________________________*/

/* Q1
clock_t deb = clock();

int n;
for(int i = 1; i <= 5; i++){
    printf("saisir un nombre\n");
    scanf("%d",&n);
}

clock_t fin = clock();

float time = (fin - deb) / (float)CLOCKS_PER_SEC;

printf("le temps passse pour fair ce programme est de : %.2f",time);

/*_________________________________________________________________________*/

// Q1

clock_t deb = clock();
//printf("\n %.2f \n",deb);






int size = strtol(argv[1],NULL,10);

float* tab1 = allocTabFloat(size);
float* tab2 = allocTabFloat(size);
float* tab3 = allocTabFloat(size);

srand(time(NULL));

for(int i = 0; i < size; i++){
    tab1[i] = rand() % 10;
    printf("| %3.2f |",tab1[i]);
    if(i+1 % 20 == 0) printf("\n");
    Sleep(3);

}

printf("\n\n\n");

for(int i = 0; i < size; i++){
    tab2[i] = rand() % 10;
    printf("| %3.2f |",tab2[i]);
    if(i+1 % 20 == 0) printf("\n");
    Sleep(3);

}
printf("\n\n\n");


for(int i = 0; i < size; i++){
    tab3[i] = rand() % 10;
    printf("| %3.2f |",tab3[i]);
    if(i+1 % 20 == 0) printf("\n");
    Sleep(3);

}
printf("\n\n\n\n\n\n");



clock_t deb1 = clock();
triBulles(tab1, size);
afficheTab(tab1);
printf("\n\n");

clock_t fin1 = clock();
printf("\nle temps passe pour tri par bull est de : %.7f s\n",(fin1 - deb1)/ (float)CLOCKS_PER_SEC);
printf("______________________________________________________________________\n\n\n");


clock_t deb2 = clock();
triSel(tab2, 1);
afficheTab(tab2);
printf("\n\n");

clock_t fin2 = clock();
printf("\nle temps passe pour tri par insertion est de : %.7f s\n",(fin2 - deb2)/ (float)CLOCKS_PER_SEC);
printf("______________________________________________________________________\n\n\n");


clock_t deb3 = clock();
pivot(tab3, 0,size);
afficheTab(tab3);
printf("\n\n");

clock_t fin3 = clock();
printf("\nle temps passe pour tri rapid est de : %.7f s\n",(fin3 - deb3)/ (float)CLOCKS_PER_SEC);
printf("______________________________________________________________________\n\n\n");















clock_t fin = clock();
printf("\n%.7f \n",fin);
printf("le temps passe est de : %.7f s",(fin - deb)/ (float)CLOCKS_PER_SEC);

/*_________________________________________________________________________*/


    return 0;
}
