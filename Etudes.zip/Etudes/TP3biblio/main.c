#include <stdio.h>
#include <stdlib.h>
#include "alloc.h"


int main()
{

int taille;
printf("saisir la taille\n");
scanf("%d",&taille);

float *tab = allocTabFloat(taille);

remplitTab(tab , taille);

for(int i = 0;  i < taille; i++){
        tab[i] = 0.0;
        printf(" %.2f |",tab[i]);
}

    return 0; //main();
}
