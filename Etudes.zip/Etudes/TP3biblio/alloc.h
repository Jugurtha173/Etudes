#ifndef ALLOC_H_INCLUDED
#define ALLOC_H_INCLUDED

float *allocTabFloat(int size);

void remplitTab(float *tab, int size);

#endif // ALLOC_H_INCLUDED
