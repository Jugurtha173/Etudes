#include <stdio.h>
#include <stdlib.h>
#include "alloc.h"

#define max 20
#define min 0


float *allocTabFloat(int size){
    float *tab = (float *)malloc(sizeof(float) * size);
    return tab;
}

void remplitTab(float *tab, int size){
    for(int i = 0;  i < size; i++){
        tab[i] = (rand() % (max - min +1) + min);
        printf(" %.2f |",tab[i]);
    }

}

