#ifndef TRI_H_INCLUDED
#define TRI_H_INCLUDED

void afficheTab(int tab[]);

void afficheMat(int n, int m, int** tabNotes);

void triBulles(int tab[], int taille);

void insert(int tab[], int i, int j);

void triSel(int tab[], int ind);

int pivot(int tab[], int t1, int t2);
#endif // TRI_H_INCLUDED
