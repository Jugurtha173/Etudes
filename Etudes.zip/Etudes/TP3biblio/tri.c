#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define max 20
#define min 0

#define Taille 50
#define SIZE_MAX 50

void afficheTab(float *tab){
for(int i = 1 ; i <= Taille ; i++){
    printf(" %.2f |",tab[i-1]);
    if(i % 10 == 0)
        printf("\n");
}
}

void afficheMat(int n, int m, int** tabNotes){
for(int i = 0; i < n; i++){
    for(int j = 0; j < m;j++){
        printf(" %3d |",tabNotes[i][j]);

    }
    printf("\n");
}
printf("______________________________________________________________________________________________\n\n");
}

void triBulles(float *tab, int taille){
    int temp;
    for(int j = 0; j < taille ; j++){
        for(int i = 0; i < taille-j ; i++){
            if(tab[i] > tab[i+1]){
                temp = tab[i];
                tab[i] = tab[i+1];
                tab[i+1] = temp;
            }
        }
    }
}

void insert(float *tab, int i, int j){
    int temp = tab[i];
    for(int k = i; k > j; k--)
        tab[k] = tab[k-1];
    tab[j] = temp;
}

void triSel(float *tab, int ind){
    for(int i = ind; i<SIZE_MAX; i++){
        for(int j = 0; j < i; j++){
            if( ((tab[i] < tab[j]) && (tab[i] >= tab[j-1])) || ( (j==0) && (tab[i] < tab[j]) ) ){
                insert(tab ,i, j);
            }
        }
    }
}


int cmp=0;
int pivot(float *tab, int t1, int t2){
    int piv = t1;
if(t1 < t2){
    for(int i = piv+1 ; i <= t2 ; i++){
        if(tab[piv] > tab[i]){
           // printf("_________________________________appel numero : %d_________________________________\n\n",cmp++);
            insert(tab , i , piv);
            piv++;
        }
    }
       pivot(tab , t1 , piv);
       pivot(tab , piv+1 , t2) ;
}
return piv;
}
