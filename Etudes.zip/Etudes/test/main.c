#include <stdio.h>
#include <stdlib.h>
//#define Taille_MAX = 100

typedef struct {
    int jour;
    int mois;
    int annee;
    }date;

typedef enum{ Zumba, Musculation, Football, Basketball
}activite;

typedef struct{
    char nom[50] , prenom[50];
    date DDN;
    int poids;
    activite sport;
}personne;

int main()
{
    personne tab[100];

    for(int i = 0; i<2; i++){
        printf("saisir les infos de la personne numero %d \n",i);

        printf("saisir le nom\n");
        scanf("%s",&tab[i].nom);

        printf("saisir le prenom\n");
        scanf("%s",&tab[i].prenom);

        printf("saisir le jour\n");
        scanf("%d",&tab[i].DDN.jour);

        printf("saisir le mois\n");
        scanf("%d",&tab[i].DDN.mois);

        printf("saisir l'annee\n");
        scanf("%d",&tab[i].DDN.annee);

        printf("saisir le poids\n");
        scanf("%d",&tab[i].poids);

        printf("saisir l'activite\n");
        scanf("%d",&tab[i].sport);
    }

    for(int i = 0; i<2; i++){
        printf("-------------------------------------------------------\nles infos de la personne numero %d \n",i);
        printf("%s \n %s \n",tab[i].nom , tab[i].prenom);
        printf("%d \n",tab[i].DDN.jour);
        printf("%d \n",tab[i].DDN.mois);
        printf("%d \n",tab[i].DDN.annee);
        printf("%.2f \n",(float)(tab[i].poids / 1000.0));
        switch (tab[i].sport){
        case 0: printf("Zumba");
        break;
        case 1: printf("Musculation");
        break;
        case 2: printf("Football");
        break;
        case 3: printf("Basketball");
        break;
        default : printf("wesh tu fait R frere");
        }
    }



    return 0;
}
