#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define max 100
#define min 0

//char nom[50],prenom[50];
//int a;
//float b,c;
//int annee,mois;
//int h ,n;
//int max,min;


int main()
{
/* Q1
printf("saisir votre prenom\n");
scanf("%s",&prenom);

printf("saisir votre nom\n");
scanf("%s",&nom);

printf("bonjour %s %s", prenom , nom);
/*______________________________________________________________________________________________________________________*/

/* Q2 printf("%X",38);

/*______________________________________________________________________________________________________________________*/

/* Q3
printf("saisir votre la 1ere valeur\n");
scanf("%f",&a);
printf("saisir votre la 2eme valeur\n");
scanf("%f",&b);
printf("saisir votre la 2eme valeur\n");
scanf("%f",&c);

printf("avant\na = %.2f \nb= %.2f\nc = %.2f\n",a,b,c);

int temp = a;
a = b;
b = c;
c = temp;

printf("apres\na = %.2f \nb= %.2f\nc = %.2f\n",a,b,c);

/*______________________________________________________________________________________________________________________*/

/* Q4
printf("saisir votre la 1ere valeur\n");
scanf("%d",&a);
printf("saisir votre la 2eme valeur\n");
scanf("%f",&b);

c = b/a;
printf("c = %.2f\n",c);
/*______________________________________________________________________________________________________________________*/

/* Q1
printf("saisir l'annee\n");
scanf("%d",&annee);

if((annee % 400 == 0) || (annee % 4 == 0 && annee % 100 != 0))
    printf("l'annee %d est bisextille\n",annee);
else
    printf("l'annee %d n'est pas bisextille\n",annee);

/*______________________________________________________________________________________________________________________*/

/* Q2
printf("saisir le mois\n");
scanf("%d",&mois);

switch (mois){
case 1:
case 3:
case 5:
case 7:
case 8:
case 10:
case 12: printf("31 jours");
break;
case 2: printf("28 ou 29 jours");
break;
default : printf("30 jours");
/*______________________________________________________________________________________________________________________*/

/* Q4
printf("saisir la hauteur\n");
scanf("%d",&h);

int i,j,k;

for(i = 0; i<h; i++){

    for( int l=i+1; l<h; l++)
        printf(" ");

    for(j=0; j<i;j++)
        printf("%d",j);

    for(k=j ; k>=0; k--)
        printf("%d",k);


printf("\n");
}
/*______________________________________________________________________________________________________________________*/

/* Q3
printf("saisir une valeur n \n");
scanf("%d",&n);
int cpt = 0;
for(int i = 1; i<n; i++){
    if(n % i == 0){
    cpt += i;
    printf("%d\n",i);
    }
}
if(cpt == n)
    printf("le nombre %d est parfait",n);
else
    printf("le nombre %d n'est pas parfait",n);

/*______________________________________________________________________________________________________________________*/

/* Q9
printf("saisir la valeur n\n");
scanf("%d",&n);

int u0 = 1;
int u1 = 1;

int i = 0;
int un = 0;

do{
    un = u0 + u1;
    u0 = u1;
    u1 = un;
    i++;

}while( i <= n);

printf("feb de n = %d\n", un);
/*______________________________________________________________________________________________________________________*/

/* Q1 et Q2

srand(time(NULL));

int tab[100];

for(int i = 0; i<100; i++){
    tab[i] = (rand() % (max - min +1) + min);

        if(tab[i] % 2 == 0)
            printf("%2d  |  ", tab[i]);
}
/*______________________________________________________________________________________________________________________*/

/* Q3
printf("saisir max \n");
scanf("%d",&max);

printf("saisir min \n");
scanf("%d",&min);

printf("une valeur une %d et %d : %d" , max, min, (rand() % (max - min +1) + min));

/*______________________________________________________________________________________________________________________*/

/* Q4
srand(time(NULL));

int tab[100];

for(int i = 0; i<100; i++){
    tab[i] = (rand() % (max - min +1) + min);
        if( i % 5 == 0)
            printf("\n");

    printf("%3d  |  ", tab[i]);
}
/*______________________________________________________________________________________________________________________*/

/* Q5
srand(time(NULL));

int tab[100];
int somme = 0;

for(int i = 0; i<100; i++)
    tab[i] = (rand() % (max - min +1) + min);

for(int i =0; i<100; i++){
    somme += tab[i];
}

printf("la moyenne des valeurs du tableau = %.2f", (float)somme / 100);

/*______________________________________________________________________________________________________________________*/

/* Q6
srand(time(NULL));

int tab[100];
int indMin = 0, indMax = 0;

for(int i = 0; i<100; i++)
    tab[i] = (rand() % (max - min +1) + min);

int maxTab = tab[0] , minTab = tab[0];

for(int i = 1; i < 100; i++)
        if (tab[i] > maxTab){
            maxTab = tab[i];
            indMax = i;
        }

for(int i = 1; i < 100; i++)
    if (tab[i] < minTab){
        minTab = tab[i];
        indMin = i;
    }

printf("la valeur min = %d a l'indice %d\nla valeur max = %d a l'indice %d", minTab,indMin,maxTab,indMax);



/*______________________________________________________________________________________________________________________*/

/* Q7
srand(time(NULL));

int tab[100], tabPos[100], tabNeg[100], indPos = 0,indNeg = 0;

for(int i = 0; i<100; i++){
    tab[i] = (rand() % (max - min +1) + min);
    tabPos[i] = 0;
    tabNeg[i] = 0;
}

for(int i = 0; i < 100; i++){
    if(tab[i] >= 0){
        tabPos[indPos] = tab[i];
        indPos++;
    }else{
        tabNeg[indNeg] = tab[i];
        indNeg++;
    }

}

for(int i = 1; i<=100; i++){
    printf("%3d  | ", tab[i-1]);
    if( i % 10 == 0)
        printf("\n");

}
    printf("\n");
    printf("\n");
    printf("\n");

for(int i = 1; i<=100; i++){
    printf("%3d  | ", tabPos[i-1]);
    if( i % 10 == 0)
        printf("\n");

}
    printf("\n");
    printf("\n");
    printf("\n");


for(int i = 1; i<=100; i++){
    printf("%3d  | ", tabNeg[i-1]);
    if( i % 10 == 0)
        printf("\n");
}

/*______________________________________________________________________________________________________________________*/

/* Q8

int n,tab[8];

for(int i = 0; i<8; i++){
    tab[i] = 0;
}

printf("saisir un nombre\n");
scanf("%d",&n);

int temp = n;

for(int i = 0; i < n; i++){
    if(temp != 0){
        tab[i] = (temp % 2);
        temp /= 2;
    }
}

for(int i = 7; i >= 0; i--){
    printf(" %d |",tab[i]);

}
/*______________________________________________________________________________________________________________________*/

/* Q9
int temp,tab[100];

srand(time(NULL));

for(int i = 0; i<100; i++){
    tab[i] = (rand() % (max - min +1) + min);
}

for(int i = 1; i<=100; i++){
    printf(" %3d |",tab[i-1]);
    if(i % 10 == 0 && i!= 0)
        printf("\n");
}

        printf("\n");
        printf("\n");
        printf("\n");


for(int i = 0; i<100; i++)
    for(int j = i+1; j<100; j++)
        if( tab[i] > tab[j]){
            temp = tab[i];
            tab[i] = tab[j];
            tab[j] = temp;
}

for(int i = 1; i<=100; i++){
    printf(" %3d |",tab[i-1]);
    if(i % 10 == 0 && i!= 0)
        printf("\n");
}

/*______________________________________________________________________________________________________________________*/

/* Q3

char ch[50];
int n;

printf("saisir un mot\n");
scanf("%s",ch);

printf("saisir un nombre\n");
scanf("%d",&n);

for(int i = 0; i<n;i++){
    for(int j = 0; j<=i;j++)
        printf("%c",ch[j]);

        printf("\n");
}

/*______________________________________________________________________________________________________________________*/


    return 0;
}
