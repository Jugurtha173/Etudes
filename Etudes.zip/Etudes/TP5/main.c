#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

int main()
{
    pile p = creerPileVide();

    affichePile(p);

    p = empiler(p , 'a');
    p = empiler(p , 'm');
    p = empiler(p , 's');
    p = empiler(p , 'a');

    affichePile(p);

    printf("la tete de la pile est : %c\n", tetePile(p));


    printf("\n\n\n\n");

    p = depiler(p);

    affichePile(p);


    printf("la tete de la pile est : %c\n", tetePile(p));


    p = viderTout(p);

    affichePile(p);

    return 0;
}
