#include <stdbool.h>
#include "liste.h"
#include <stdio.h>
#include <stdlib.h>

pile creerPileVide(){
    pile p = NULL;
    return p;
}

bool estVide(pile P){
    return (P == NULL);
}

pile empiler(pile P, char v){
    pile element = (pile)malloc(sizeof(struct cellule));
    element->val = v;
    element->suiv = P;

    return element;
}

void affichePile (pile P){
    if( estVide(P) )
        printf("la pile est vide\n");
    else
        while(P != NULL){
            printf("| %c |\n",P->val);
            printf("-----\n");
            P = P->suiv;
        }

}

pile depiler(pile P){
    if(P != NULL){
        pile tmp = P;
        P = P->suiv;
        free(tmp);
        return P;
    }else
        return NULL;
}

char tetePile(pile P){
    return P->val;
}

pile viderTout(pile P){

    while( P != NULL ){
        P = depiler(P);
    }

    return P;
}
