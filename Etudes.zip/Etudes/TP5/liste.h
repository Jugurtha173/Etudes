#ifndef LISTE_H_INCLUDED
#define LISTE_H_INCLUDED

#include <stdbool.h>

typedef struct cellule{
    char val;
    struct cellule *suiv;
}*pile;

pile creerPileVide();

bool estVide(pile P);

pile empiler(pile P, char v);

void affichePile (pile P);

pile depiler(pile P);

char tetePile(pile P);

pile viderTout(pile P);

#endif // LISTE_H_INCLUDED
